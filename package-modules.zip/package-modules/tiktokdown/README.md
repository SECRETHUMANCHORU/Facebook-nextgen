## TIKTOK DOWNLOAD VIDEO OR MUSIC

How to use:
```javascript
const TiktokDown = require('tiktokdown'); 
const link = 'https://vt.tiktok.com/ZSLTXkcyY/';
(async () => {
  const tiktokDownloader = new TiktokDown();
  const result = await tiktokDownloader.download(link);

  console.log("Tiktok and Ssstik Result:");
  
  console.log(result.tikwn);
  
  console.log(result.ssstik);
})();


```
## RESULT
![Downloadtiktok](https://naol.secrethumanchor.repl.co/IMG_20230910_183611.jpg)

## SSSTIK
<img src="https://naol.secrethumanchor.repl.co/ssstik.png" alt="https://ssstik.io/en" width="100%">

## TIKWM
<img src="https://naol.secrethumanchor.repl.co/tikwm.jpeg" alt="https://www.tikwm.com" width="100%">

Copyrights 2023
Scrape Choru TikTokers