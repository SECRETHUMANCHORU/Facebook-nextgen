const TiktokDown = require('./src/tiktok');
module.exports = TiktokDown;
